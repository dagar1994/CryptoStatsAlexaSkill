# -*- coding: utf-8 -*-
"""
This skill gives you stats about the current ongoing crypto currency market
"""

from __future__ import print_function
import requests
import json
import inflect
from bs4 import BeautifulSoup



# --------------- Helpers that build all of the responses ----------------------

def build_speechlet_response(title, output, reprompt_text, should_end_session):
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': output
        },
        'card': {
            'type': 'Simple',
            'title':  title,
            'content':  output
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }


def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }


# --------------- Functions that control the skill's behavior ------------------


def help_response():
    session_attributes = {}
    card_title = "Help"
    speech_output = """


To know the top three currencies say "What are the top crypto currencies".
To know the highest gaining currency in last 24 hours say "which is the highest gaining crypto currency in last 24 hours",Stats for last 1 hour and last week are also available for both gaining and falling currencies.
To know the highest priced currency say "which is the most expensive crypto currency", information for the least priced is also available.
Now you can also aks me what are the top picks for longterm investments , top picks for this month , week , for adoption and according to people are also available.
			""".strip() 
    # If the user either does not reply to the welcome message or says something
    # that is not understood, they will be prompted again with this text.
    reprompt_text = "Know the latest trends of the crypto currency market from crypto stats. " \
                        "Ask me which are the top 3 crypto currencies or which are the highest gaining curreny in last seven days."
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def cancel_response():
    session_attributes = {}
    card_title = "User Ended the skill"
    speech_output = """
	Thank you for using Crypto stats, I hope the information was helpful.
			""".strip() 
    # If the user either does not reply to the welcome message or says something
    # that is not understood, they will be prompted again with this text.
    reprompt_text = "Know the latest trends of the crypto currency market from crypto stats. " \
                        "Ask me which are the top 3 crypto currencies or which are the highest gaining curreny in last seven days."
    should_end_session = True
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))




def get_welcome_response():
    """ If we wanted to initialize the session to have some attributes we could
    add those here
    """

    session_attributes = {}
    card_title = "Welcome"
    speech_output = "Welcome to crypto stats. " \
	            "Ask me which are the top 3 crypto currencies or which are the highest gaining curreny in last seven days. "\
		    "Now you can also aks me what are the top picks for longterm investments"
    # If the user either does not reply to the welcome message or says something
    # that is not understood, they will be prompted again with this text.
    reprompt_text = "Know the latest trends of the crypto currency market from crypto stats." \
	            "Ask me which are the top 3 crypto currencies or which are the highest gaining curreny in last seven days. "\
		    "Now you can also aks me what are the top picks for longterm investments"
    should_end_session = False
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def handle_session_end_request():
    card_title = "Session Ended"
    speech_output = "Thank you for using Crypto stats, I hope the information was helpful." 
    # Setting this to true ends the session and exits the skill.
    should_end_session = True
    return build_response({}, build_speechlet_response(
        card_title, speech_output, None, should_end_session))


def topPicks(intent, session):
    session_attributes = {}
    reprompt_text = None

    if len(intent['slots']['picksType']) == 1:
            should_end_session = False
            speech_output ='Sorry, your request was not clear. To know the top picks for this week, say What are the top picks for this week'
            reprompt_text = "Say What are the top picks for this week"

            return build_response(session_attributes, build_speechlet_response(
                   "Request about the top picks not clear"  , speech_output, reprompt_text, should_end_session))

    try:
	    page = requests.get("https://cryptonaire.com/")
	    soup = BeautifulSoup(page.content, 'html.parser',from_encoding="ascii")
    	    allTop = soup.find_all("div" , {"class" : "col-md-15"})
	    pickType = intent['slots']['picksType']['value']
	    if (pickType.strip() == "seven day" or pickType.strip() == "seven days" or pickType.strip() == "week"):
		    speechForm = "this week"
		    rowData = allTop[0].find_all('td')
		    data = [rowData[2].text.split("(")[0],rowData[5].text.split("(")[0],rowData[8].text.split("(")[0],rowData[11].text.split("(")[0],rowData[14].text.split("(")[0]]
		    number5 = data[4] + " at number 5, "		    
		    number4 = data[3] + " at number 4, "		    
		    number3 = data[2] + " at number 3, "		    
		    number2 = data[1] + " at number 2, and "		    
		    number1 = data[0] + " at top "
		    speech_output = 'The top picks for ' + speechForm + " are as follows. " +  number5 + number4 + number3 + number2 + number1
		    reprompt_text = "Say What are the top picks for " + speechForm
	    elif (pickType.strip() == "thirty day" or pickType.strip() == "months" or pickType.strip() == "month"):
                    speechForm = "this month"
                    rowData = allTop[1].find_all('td')
                    data = [rowData[2].text.split("(")[0],rowData[5].text.split("(")[0],rowData[8].text.split("(")[0],rowData[11].text.split("(")[0],rowData[14].text.split("(")[0]]
		    number5 = data[4] + " at number 5, "		    
		    number4 = data[3] + " at number 4, "		    
		    number3 = data[2] + " at number 3, "		    
		    number2 = data[1] + " at number 2, and "		    
		    number1 = data[0] + " at top "
	
                    speech_output = 'The top picks for ' + speechForm + " are as follows. " + number5 + number4 + number3 + number2 + number1
                    reprompt_text = "Say What are the top picks for " + speechForm
            elif (pickType.strip() == "longterm" or pickType.strip() == "long-term" or pickType.strip() == "long"):
                    speechForm = "longterm investment"
                    rowData = allTop[2].find_all('td')
                    data = [rowData[2].text.split("(")[0],rowData[5].text.split("(")[0],rowData[8].text.split("(")[0],rowData[11].text.split("(")[0],rowData[14].text.split("(")[0]]
		    number5 = data[4] + " at number 5, "		    
		    number4 = data[3] + " at number 4, "		    
		    number3 = data[2] + " at number 3, "		    
		    number2 = data[1] + " at number 2, and "		    
		    number1 = data[0] + " at top "
	

                    speech_output = 'The top picks for ' + speechForm + " are as follows. " + number5 + number4 + number3 + number2 + number1
                    reprompt_text = "Say What are the top picks for " + speechForm
            elif (pickType.strip() == "adoption" or pickType.strip() == "adoptions" or pickType.strip() == "adopting"):
                    speechForm = "adoptions"
                    rowData = allTop[3].find_all('td')
                    data = [rowData[2].text.split("(")[0],rowData[5].text.split("(")[0],rowData[8].text.split("(")[0],rowData[11].text.split("(")[0],rowData[14].text.split("(")[0]]
		    number5 = data[4] + " at number 5, "		    
		    number4 = data[3] + " at number 4, "		    
		    number3 = data[2] + " at number 3, "		    
		    number2 = data[1] + " at number 2, and "		    
		    number1 = data[0] + " at top "
	
                    speech_output = 'The top picks for ' + speechForm + " are as follows. " + number5 + number4 + number3 + number2 + number1
                    reprompt_text = "Say What are the top picks for " + speechForm
            elif (pickType.strip() == "people" or pickType.strip() == "peoples" or pickType.strip() == "community"):
                    speechForm = "investment according to the people"
                    rowData = allTop[4].find_all('td')
                    data = [rowData[2].text.split("(")[0],rowData[5].text.split("(")[0],rowData[8].text.split("(")[0],rowData[11].text.split("(")[0],rowData[14].text.split("(")[0]]
		    number5 = data[4] + " at number 5, "		    
		    number4 = data[3] + " at number 4, "		    
		    number3 = data[2] + " at number 3, "		    
		    number2 = data[1] + " at number 2, and "		    
		    number1 = data[0] + " at top "
	
                    speech_output = 'The top picks for ' + speechForm + " are as follows. " + number5 + number4 + number3 + number2 + number1
                    reprompt_text = "Say What are the top picks for " + speechForm
	    should_end_session = True

            return build_response(session_attributes, build_speechlet_response(
                    'The top picks for ' + speechForm, speech_output, reprompt_text, should_end_session))
    except:
	    should_end_session = True
	    return build_response(session_attributes, build_speechlet_response(
                    'Data not available right now', "Sorry for the inconvenience but the data is not available right now", "Sorry for the inconvenience but the data is not available right now", should_end_session))	
		    	    
	


def currency_price(intent, session):
    session_attributes = {}
    reprompt_text = None
 
    if len(intent['slots']['currencyName']) == 1:
	    should_end_session = False
	    speech_output ='Please specify the currency for whcih you want to know the price. For example, Say what is the current price of ripple to know latest ripple price related statistics.'
	    reprompt_text = "Say, what is the current price of ripple to know latest ripple price related statistics."

	    return build_response(session_attributes, build_speechlet_response(
                   "Currency name not specified"  , speech_output, reprompt_text, should_end_session))


    try:
	#    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/"
	    currency = intent['slots']['currencyName']['value']
	    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/" + currency



	    request = requests.get(allCurrencyInfoUrl)

	    data = json.loads(request.text)

	    if float(data[0]['percent_change_1h']) < 0:
		    percent_change_1h = ',decreased by ' + str(abs(float(data[0]['percent_change_1h']))) + ' percent in last 1 hour'
	    else:
		    percent_change_1h = ',increased by ' + str(abs(float(data[0]['percent_change_1h']))) + ' percent in last 1 hour'


	    if float(data[0]['percent_change_24h']) < 0:
		    percent_change_24h = ',decreased by ' + str(abs(float(data[0]['percent_change_24h']))) + ' percent in last 24 hour'
	    else:
		    percent_change_24h = ',increased by ' + str(abs(float(data[0]['percent_change_24h']))) + ' percent in last 24 hour'

	    if float(data[0]['percent_change_7d']) < 0:
		    percent_change_7d = ',decreased by ' + str(abs(float(data[0]['percent_change_7d']))) + ' percent in last 7 days'
	    else:
		    percent_change_7d = ',increased by ' + str(abs(float(data[0]['percent_change_7d']))) + ' percent in last 7 days'

	    speech_output ='Current price of ' + currency + ' is ' + data[0]['price_usd'] + '$. ' +currency + '\'s price ' + str(percent_change_1h) + str(percent_change_24h) + str(percent_change_7d) 
	    reprompt_text = "Say, what is the current price of ripple to know latest ripple price related statistics."
    except:
	    speech_output = "Statistics for " + intent['slots']['currencyName']['value'] + " crypto currency are not available."
	    reprompt_text = "Statistics for " + intent['slots']['currencyName']['value'] + " crypto currency are not available."
    should_end_session = True        

    return build_response(session_attributes, build_speechlet_response(
        'Current price of ' + intent['slots']['currencyName']['value'], speech_output, reprompt_text, should_end_session))

 
def currency_available_total(intent, session):
    session_attributes = {}
    reprompt_text = None

    if len(intent['slots']['currencyName']) == 1:
	    should_end_session = False
	    speech_output ='Please specify the currency for whcih you want to know the number of coins available in the market. For example, Say number of bitcoin.'
	    reprompt_text = "To know the available dash coins in the markey say Ask crypto stats, number of dash."

	    return build_response(session_attributes, build_speechlet_response(
                   'Currency name not specified.', speech_output, reprompt_text, should_end_session))

 
    try: 
	#    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/"
	    currency = intent['slots']['currencyName']['value']
	    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/" + currency



	    request = requests.get(allCurrencyInfoUrl)

	    data = json.loads(request.text)
	    total_availbe = data[0]['total_supply']
	    p = inflect.engine()
	    total_availbe = p.number_to_words(total_availbe)
	    speech_output = "Total number of " + currency + "'s available are " + total_availbe + "."
	    reprompt_text = "To know the available dash coins in the markey say Ask crypto stats, number of dash."
    except:
	    speech_output = "Statistics for " + intent['slots']['currencyName']['value'] + " crypto currency are not available."
	    reprompt_text = "Statistics for " + intent['slots']['currencyName']['value'] + " crypto currency are not available."
    should_end_session = True       

    return build_response(session_attributes, build_speechlet_response(
        "Number of " +  intent['slots']['currencyName']['value'], speech_output, reprompt_text, should_end_session))

    
 
def highestValue(intent, session):
    session_attributes = {}
    reprompt_text = None
    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/"

    request = requests.get(allCurrencyInfoUrl)

    data = json.loads(request.text)
    highestPrice = 0.00
    highestCoin = "None"

    for index in data:
        try:
                if float(index['price_usd']) > highestPrice:
                        highestPrice = float(index['price_usd'])
                        highestCoin = index['name']
        except:
                continue

    speech_output = "Currently the highest priced crypto currency is " + str(highestCoin) + " holding the value of  " + str(highestPrice) + "$."
    reprompt_text = "To know the lowest priced coin say, Ask crypto advisor which is the lowest priced crypto currency."
    should_end_session = True

    return build_response(session_attributes, build_speechlet_response(
        "Highest priced coin!", speech_output, reprompt_text, should_end_session))

    

 
   
 
def lowestValue(intent, session):
    session_attributes = {}
    reprompt_text = None
    
    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/"
    



    request = requests.get(allCurrencyInfoUrl)

    data = json.loads(request.text)
    lowestPrice = 1000000000000000.00
    lowestCoin = "None"


    for index in data:
        try:
                if float(index['price_usd']) < lowestPrice:
                        lowestPrice = float(index['price_usd'])
                        lowestCoin = index['name']
        except:
                continue

    speech_output = "Currently the lowest priced crypto currency is " + str(lowestCoin) + " holding the value of  " + str(lowestPrice) + "$."
    reprompt_text = "To know the highest priced coin say, Ask crypto advisor which is the lowest priced crypto currency."
    should_end_session = True

    return build_response(session_attributes, build_speechlet_response(
        "Lowest priced coin!", speech_output, reprompt_text, should_end_session))

    

 
  
def topCurrency(intent, session):
    session_attributes = {}
    reprompt_text = None
    
    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/"
    



    request = requests.get(allCurrencyInfoUrl)
    data = json.loads(request.text)	
    number1 = data[0]["name"]
    number2 = data[1]["name"]
    number3 = data[2]["name"]
    number1Price = data[0]['price_usd']
    number2Price = data[1]['price_usd']
    number3Price = data[2]['price_usd']
    number1Out = str(number1) + " at number1 holding the value of " + str(number1Price) + "$." 
    number2Out = str(number2) + " at number2 holding the value of " + str(number2Price) + "$." 
    number3Out = str(number3) + " at number3 holding the value of " + str(number3Price) + "$." 
    speech_output = "The top 3 crypto currencies are,  " + str(number3Out) + "   " + str(number2Out) + "   " + str(number1Out)
    reprompt_text = "To know deatiled information say : Tell me about marijuana in detail."
    should_end_session = True       

    return build_response(session_attributes, build_speechlet_response(
        "Top 3 Crypto currencies!", speech_output, reprompt_text, should_end_session))

    
  
 
  
def lastCurrency(intent, session):
    session_attributes = {}
    reprompt_text = None
    
    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/"
    



    request = requests.get(allCurrencyInfoUrl)
    data = json.loads(request.text)	
    number1 = data[-1]["name"]
    number2 = data[-2]["name"]
    number3 = data[-3]["name"]
    number1Price = data[-1]['price_usd']
    number2Price = data[-2]['price_usd']
    number3Price = data[-3]['price_usd']
    number1Out = str(number1) + " at last holding the value of " + str(number1Price) + "$." 
    number2Out = str(number2) + " at second last holding the value of " + str(number2Price) + "$." 
    number3Out = str(number3) + " at third last holding the value of " + str(number3Price) + "$." 
    speech_output = "The last 3 crypto currencies are,  " + str(number3Out) + "   " + str(number2Out) + "   " + str(number1Out)
    reprompt_text = "To know the last 3 crypto currencies, say which are the last crypto currencies"
    should_end_session = True        

    return build_response(session_attributes, build_speechlet_response(
        "Last 3 Crypto currencies", speech_output, reprompt_text, should_end_session))

    
 
 
  
def topGainingCurrency(intent, session):
    session_attributes = {}
    reprompt_text = None

    if len(intent['slots']['timeChange']) == 1:
            should_end_session = False
            speech_output ='Please specify the time range  for whcih you want to know the top gaining currency. Available time ranges are hour, day and week .For example, say which is the highest gaining crypto currency in last week.'
            reprompt_text = 'Please specify the time range for whcih you want to know the top gaining currency. Available time ranges are hour, day and week .For example, say which is the highest gaining crypto currency in last week.'

            return build_response(session_attributes, build_speechlet_response(
                   'Time range not specified', speech_output, reprompt_text, should_end_session))

 
    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/"
    
    timeChange = intent['slots']['timeChange']['value']
    if (timeChange.strip() == "day" or timeChange.strip() == "one day" or timeChange.strip() == "twenty four hours" or timeChange.strip() == "24 hours"):
	changeValue = "percent_change_1h"
    elif (timeChange.strip() == "hour" or timeChange.strip() == "hours" or timeChange.strip() == "one hour" ):
	changeValue = "percent_change_24h"
    elif (timeChange.strip() == "week" or timeChange.strip() == "seven day" or timeChange.strip() == "seven days" ):
	changeValue = "percent_change_7d"
    else:
	changeValue = "percent_change_24h"	
    

    request = requests.get(allCurrencyInfoUrl)
    data = json.loads(request.text)	

    highestGain = 0.00
    highestGainCoin = "None"


    for index in data:
        try:
                if float(index[changeValue]) > highestGain:
                        highestGain = float(index[changeValue])
                        highestGainCoin = index['name']
        except:
                continue

    speech_output = "The highest gaining currency in last " + str(timeChange) + " is  " + str(highestGainCoin) + " ,which incresed by " + str(highestGain) + " percent."
    reprompt_text = "To know deatiled information say : Tell me about marijuana in detail"
    should_end_session = True        

    return build_response(session_attributes, build_speechlet_response(
        'Highest gaining Crypto currency', speech_output, reprompt_text, should_end_session))

    
 
  
def topFallingCurrency(intent, session):
    session_attributes = {}
    reprompt_text = None
 
    if len(intent['slots']['timeChange']) == 1:
            should_end_session = False
            speech_output ='Please specify the time range for whcih you want to know the top falling currency. Available time ranges are hour, day and week .For example, say which is the falling gaining crypto currency in last week.'
            reprompt_text = speech_output

            return build_response(session_attributes, build_speechlet_response(
                   'Time range not specified', speech_output, reprompt_text, should_end_session))

   
    allCurrencyInfoUrl = "https://api.coinmarketcap.com/v1/ticker/"
    
    timeChange = intent['slots']['timeChange']['value']
    if (timeChange.strip() == "day" or timeChange.strip() == "one day" or timeChange.strip() == "twenty four hours" or timeChange.strip() == "24 hours"):
	changeValue = "percent_change_1h"
    elif (timeChange.strip() == "hour" or timeChange.strip() == "hours" or timeChange.strip() == "one hour" ):
	changeValue = "percent_change_24h"
    elif (timeChange.strip() == "week" or timeChange.strip() == "seven day" or timeChange.strip() == "seven days" ):
	changeValue = "percent_change_7d"
    else:
	changeValue = "percent_change_24h"	
    

    request = requests.get(allCurrencyInfoUrl)
    data = json.loads(request.text)	

    highestGain = 0.00
    highestGainCoin = "None"


    for index in data:
        try:
                if float(index[changeValue]) < highestGain:
                        highestGain = float(index[changeValue])
                        highestGainCoin = index['name']
        except:
                continue
    highestGain = -highestGain
    speech_output = "The highest falling currency in last " + str(timeChange) + " is  " + str(highestGainCoin) + " ,which decreased by " + str(highestGain) + " percent."
    reprompt_text = "To know deatiled information say : Tell me about marijuana in detail"
    should_end_session = True       

    return build_response(session_attributes, build_speechlet_response(
        'Highest falling Crypto currency', speech_output, reprompt_text, should_end_session))

    




def on_session_started(session_started_request, session):
    """ Called when the session starts """

    print("on_session_started requestId=" + session_started_request['requestId']
          + ", sessionId=" + session['sessionId'])


def on_launch(launch_request, session):
    """ Called when the user launches the skill without specifying what they
    want
    """

    print("on_launch requestId=" + launch_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # Dispatch to your skill's launch
    return get_welcome_response()


def on_intent(intent_request, session):
    """ Called when the user specifies an intent for this skill """

    print("on_intent requestId=" + intent_request['requestId'] +
          ", sessionId=" + session['sessionId'])

    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    # Dispatch to your skill's intent handlers
    if intent_name == "AMAZON.HelpIntent":
        return help_response()
    elif intent_name == "AMAZON.CancelIntent":
	return cancel_response()
    elif intent_name == "AMAZON.StopIntent":
        return cancel_response()
    elif intent_name == "CurrencyPriceIntent":
        return currency_price(intent, session)
    elif intent_name == "TopPicksIntent":
	return topPicks(intent, session)
    elif intent_name == "AvailableCurrencyTotalIntent":
        return currency_available_total(intent, session)
    elif intent_name == "lowestValueIntent":
        return lowestValue(intent, session)
    elif intent_name == "highestValueIntent":
        return highestValue(intent, session)
    elif intent_name == "topCurrencyIntent":
	return topCurrency(intent, session)
    elif intent_name == "lastCurrencyIntent":
	return lastCurrency(intent, session)
    elif intent_name == "topGainingCurrencyIntent":
	return topGainingCurrency(intent, session)
    elif intent_name == "topFallingCurrencyIntent":
        return topFallingCurrency(intent, session)
    elif intent_name == "" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    else:
        raise ValueError("Invalid intent")


def on_session_ended(session_ended_request, session):
    """ Called when the user ends the session.

    Is not called when the skill returns should_end_session=true
    """
    print("on_session_ended requestId=" + session_ended_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # add cleanup logic here


# --------------- Main handler ------------------

def lambda_handler(event, context):
    """ Route the incoming request based on type (LaunchRequest, IntentRequest,
    etc.) The JSON body of the request is provided in the event parameter.
    """
    print("event.session.application.applicationId=" +
          event['session']['application']['applicationId'])

    """
    Uncomment this if statement and populate with your skill's application ID to
    prevent someone else from configuring a skill that sends requests to this
    function.
    """
    # if (event['session']['application']['applicationId'] !=
    #         "amzn1.echo-sdk-ams.app.[unique-value-here]"):
    #     raise ValueError("Invalid Application ID")

    if event['session']['new']:
        on_session_started({'requestId': event['request']['requestId']},
                           event['session'])

    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'])
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'])
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended(event['request'], event['session'])
